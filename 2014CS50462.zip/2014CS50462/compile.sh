#!/bin/bash

g++ -o kmeans -std=c++11 -O3 kmeans.cpp
g++ -o dbscan -std=c++11 -O3 dbscan.cpp
g++ -o optics -std=c++11 -O3 optics.cpp
